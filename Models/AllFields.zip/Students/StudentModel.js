const mongoose = require("mongoose");
const Joi = require('joi');

const StudentSchema = mongoose.Schema({
  first_name: String,
  last_name: String,
  email: String,
  registration_date: Date,
  reg_no: Number,
  course: String,
  gender: String,
  mobile_no: Number,
  parent_name: String,
  parent_mobile_no: Number,
  date_of_birth: Date,
  blood_group: String,
  address: String,
});
const StudentModel=mongoose.model('Students',StudentSchema);

const validateStudent = (student) => {
  const schema = Joi.object({
    first_name: Joi.string().min(2).max(15).trim().strict().required(),
    last_name: Joi.string().min(3).max(15).trim().strict().required(),
    email: Joi.string().email().required(),
    registration_date: Joi.date().required(),
    reg_no: Joi.number().required(),
    course: Joi.string().required(),
    gender: Joi.string().required(),
    mobile_no: Joi.number().required(),
    parent_name: Joi.string().min(3).max(25).required(),
    parent_mobile_no: Joi.number().required(),
    date_of_birth: Joi.date().required(),
    blood_group: Joi.string().min(2).max(4).required(),
    address: Joi.string().required(),
  })
  return schema.validate(student)
}
module.exports = {
  StudentModel,
  validateStudent
}