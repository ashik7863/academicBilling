const mongoose = require("mongoose");
const Joi = require('joi');

const InstallmentSchema = mongoose.Schema({
  first_name: String,
  last_name: String,
  reg_no: Number,
  course_name: String,
  mobile_no: Number,
  parent_mobile_no: Number,
  installment_date:Date,
  installment_no:String,
  installment_amount:Number,
  installment_due:Number
});

const InstallmentModel=mongoose.model('Fees',InstallmentSchema);

const validateInstallment = (fees) => {
  const schema = Joi.object({
    first_name: Joi.string().min(2).max(15).required(),
    last_name: Joi.string().min(3).max(15).required(),
    reg_no: Joi.number().required(),
    course_name: Joi.string().required(),
    mobile_no: Joi.number().required(),
    parent_mobile_no: Joi.number().required(),
    installment_date:Joi.date().required(),
    installment_no:Joi.string().required(),
    installment_amount:Joi.number().required(),
  })
  return schema.validate(fees)
}
module.exports = {
  InstallmentModel,
  validateInstallment
}